#!/usr/bin/env python3
import sys
import time

# --- CONFIGURATION ---
# usage: sudo python3 type.py "Your text here"
HID_DEV = "/dev/hidg0"

# --- HID KEYCODE MAP ---
# Format: 'char': (Modifier, Keycode)
# Modifier 0x02 = Left Shift
key_map = {
    ' ': (0, 0x2c), '!': (2, 0x1e), '"': (2, 0x34), '#': (2, 0x20),
    '$': (2, 0x21), '%': (2, 0x22), '&': (2, 0x24), '\'': (0, 0x34),
    '(': (2, 0x26), ')': (2, 0x27), '*': (2, 0x25), '+': (2, 0x2e),
    ',': (0, 0x36), '-': (0, 0x2d), '.': (0, 0x37), '/': (0, 0x38),
    '0': (0, 0x27), '1': (0, 0x1e), '2': (0, 0x1f), '3': (0, 0x20),
    '4': (0, 0x21), '5': (0, 0x22), '6': (0, 0x23), '7': (0, 0x24),
    '8': (0, 0x25), '9': (0, 0x26), ':': (2, 0x33), ';': (0, 0x33),
    '<': (2, 0x36), '=': (0, 0x2e), '>': (2, 0x37), '?': (2, 0x38),
    '@': (2, 0x1f), '[': (0, 0x2f), '\\': (0, 0x31), ']': (0, 0x30),
    '^': (2, 0x23), '_': (2, 0x2d), '`': (0, 0x35), 
    '{': (2, 0x2f), '|': (2, 0x31), '}': (2, 0x30), '~': (2, 0x35),
    '\n': (0, 0x28) # Enter Key
}

# Generate a-z
for i, char in enumerate("abcdefghijklmnopqrstuvwxyz"):
    key_map[char] = (0, 0x04 + i)       # Lowercase (No modifier)
    key_map[char.upper()] = (2, 0x04 + i) # Uppercase (Shift modifier)

def send_report(modifier, code):
    # 8-byte report: [Modifier, Reserved, Key1, 0, 0, 0, 0, 0]
    report = bytearray([modifier, 0, code, 0, 0, 0, 0, 0])
    with open(HID_DEV, "wb") as f:
        f.write(report)
    
    # Tiny sleep to ensure the host registers the press
    time.sleep(0.02)

    # Release keys (Send all zeros)
    with open(HID_DEV, "wb") as f:
        f.write(bytearray(8))
    
    # Sleep before next key
    time.sleep(0.02)

def type_string(text):
    for char in text:
        if char in key_map:
            mod, code = key_map[char]
            send_report(mod, code)
        else:
            print(f"Skipping unknown char: {char}")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: sudo python3 type.py \"Your text here\"")
        sys.exit(1)
    
    text_to_type = sys.argv[1]
    print(f"Typing: {text_to_type}")
    
    # 2 second delay so you have time to click the window!
    print("Starting in 2 seconds...")
    time.sleep(2) 
    
    type_string(text_to_type)
    print("Done.")