#!/usr/bin/env python3
import os
import time
import sys

# === CONFIGURATION ===
# The USB gadget device file (Standard for PinePhone BadUSB)
HID_DEV = "/dev/hidg0"

# The attack URL (Updated to the working English version)
FAKE_UPDATE_URL = "https://fakeupdate.net/win10ue/"
RICKROLL_URL = "https://www.youtube.com/watch?v=dQw4w9WgXcQ"

# === KEYBOARD CODES (HID Usage Tables) ===
# Modifiers
NULL_CHAR = chr(0)
MOD_NONE = chr(0)
MOD_LCTRL = chr(1)
MOD_LSHIFT = chr(2)
MOD_LALT = chr(4)
MOD_LMETA = chr(8) # Windows Key

# Keycodes
KEY_NONE = chr(0)
KEY_ENTER = chr(40)
KEY_ESC = chr(41)
KEY_BACKSPACE = chr(42)
KEY_TAB = chr(43)
KEY_SPACE = chr(44)
KEY_F11 = chr(68)
KEY_RIGHT = chr(79)
KEY_LEFT = chr(80)
KEY_R = chr(21)  # 'r' key code

# Character Map (For typing strings)
# Maps characters to (Modifier, Keycode)
# This is a basic map. You can add more symbols if needed.
charmap = {
    'a': (MOD_NONE, chr(4)), 'b': (MOD_NONE, chr(5)), 'c': (MOD_NONE, chr(6)),
    'd': (MOD_NONE, chr(7)), 'e': (MOD_NONE, chr(8)), 'f': (MOD_NONE, chr(9)),
    'g': (MOD_NONE, chr(10)), 'h': (MOD_NONE, chr(11)), 'i': (MOD_NONE, chr(12)),
    'j': (MOD_NONE, chr(13)), 'k': (MOD_NONE, chr(14)), 'l': (MOD_NONE, chr(15)),
    'm': (MOD_NONE, chr(16)), 'n': (MOD_NONE, chr(17)), 'o': (MOD_NONE, chr(18)),
    'p': (MOD_NONE, chr(19)), 'q': (MOD_NONE, chr(20)), 'r': (MOD_NONE, chr(21)),
    's': (MOD_NONE, chr(22)), 't': (MOD_NONE, chr(23)), 'u': (MOD_NONE, chr(24)),
    'v': (MOD_NONE, chr(25)), 'w': (MOD_NONE, chr(26)), 'x': (MOD_NONE, chr(27)),
    'y': (MOD_NONE, chr(28)), 'z': (MOD_NONE, chr(29)),
    '1': (MOD_NONE, chr(30)), '2': (MOD_NONE, chr(31)), '3': (MOD_NONE, chr(32)),
    '4': (MOD_NONE, chr(33)), '5': (MOD_NONE, chr(34)), '6': (MOD_NONE, chr(35)),
    '7': (MOD_NONE, chr(36)), '8': (MOD_NONE, chr(37)), '9': (MOD_NONE, chr(38)),
    '0': (MOD_NONE, chr(39)),
    ' ': (MOD_NONE, KEY_SPACE),
    '.': (MOD_NONE, chr(55)), '/': (MOD_NONE, chr(56)),
    '-': (MOD_NONE, chr(45)), '=': (MOD_NONE, chr(46)),
    ':': (MOD_LSHIFT, chr(51)), '?': (MOD_LSHIFT, chr(56)),
    '_': (MOD_LSHIFT, chr(45)), '+': (MOD_LSHIFT, chr(46)),
}

# === CORE FUNCTIONS ===

def write_report(report):
    """Writes the 8-byte HID report to the gadget file."""
    try:
        with open(HID_DEV, 'wb') as fd:
            fd.write(report.encode('latin-1'))
    except Exception as e:
        print(f"Error writing to HID: {e}")

def send_key(modifier, keycode):
    """Presses a key with a modifier, then releases it."""
    # 1. Create the report: Modifier + NULL + Keycode + Padding
    # We use chr(0)*5 because the report must be exactly 8 bytes
    report = modifier + NULL_CHAR + keycode + NULL_CHAR*5
    
    # 2. Write the report (Press down)
    write_report(report)
    
    # 3. Wait longer for the OS to register the combo
    time.sleep(0.1) 
    
    # 4. Write empty report (Release all)
    write_report(NULL_CHAR*8)
    time.sleep(0.1)

def write_string(text):
    """Types out a string character by character."""
    for char in text:
        if char.lower() in charmap:
            mod, code = charmap[char.lower()]
            # Handle shift for uppercase letters not manually mapped
            if char.isupper() and char.isalpha():
                mod = MOD_LSHIFT
            send_key(mod, code)
        else:
            # Fallback for unknown chars
            print(f"Unknown char: {char}")

# === PAYLOADS ===

def payload_fake_update():
    print("Running Fake Update...")
    # 1. Open Run Dialog (Win + R)
    # sending MOD_LMETA (Windows Key) combined with KEY_R
    send_key(MOD_LMETA, KEY_R) 
    time.sleep(1.0) # Wait 1 full second for the Run box to appear
    
    # 2. Type URL
    # We use 'cmd /c start' to open the default browser cleanly
    write_string("cmd /c start " + FAKE_UPDATE_URL)
    time.sleep(0.5)
    
    # 3. Enter
    send_key(MOD_NONE, KEY_ENTER)
    
    # 4. Wait for browser to load
    time.sleep(3)
    
    # 5. Fullscreen (F11)
    send_key(MOD_NONE, KEY_F11)
    print("Payload Complete.")

def payload_rickroll():
    print("Running Rickroll...")
    send_key(MOD_LMETA, 'r')
    time.sleep(0.5)
    write_string("cmd /c start " + RICKROLL_URL)
    time.sleep(0.5)
    send_key(MOD_NONE, KEY_ENTER)
    print("Payload Complete.")

# === MENU ===

def main():
    if not os.path.exists(HID_DEV):
        print(f"ERROR: {HID_DEV} not found. Is the USB gadget active?")
        sys.exit(1)

    # Check for command line arguments (for trigger_power.py)
    if len(sys.argv) > 1:
        if sys.argv[1] == "update":
            payload_fake_update()
            return
        elif sys.argv[1] == "rickroll":
            payload_rickroll()
            return

    # Interactive Menu
    while True:
        print("\n--- PINEPHONE ATTACK MENU ---")
        print("1. Windows Fake Update (Power Button Target)")
        print("2. Rickroll")
        print("3. Exit")
        
        choice = input("Select an option: ")
        
        if choice == "1":
            # Give user 3 seconds to switch focus to target PC
            print("Starting in 3 seconds...")
            time.sleep(3)
            payload_fake_update()
        elif choice == "2":
            print("Starting in 3 seconds...")
            time.sleep(3)
            payload_rickroll()
        elif choice == "3":
            sys.exit(0)
        else:
            print("Invalid choice.")

if __name__ == "__main__":
    main()