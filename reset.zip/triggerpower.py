#!/usr/bin/env python3
import struct
import os
import sys
import time
import re

# --- CONFIGURATION ---
# We are now targeting the Power Button
TARGET_DEVICE_NAME = "axp20x-pek" 

# 116 is the standard KEY_POWER code on Linux
TRIGGER_CODE = 116 

# Path to your attack menu
ATTACK_SCRIPT = "/home/kali/menu.py"

def get_event_path(device_name):
    """Finds the eventX file for the power button."""
    path = "/proc/bus/input/devices"
    if not os.path.exists(path):
        return None

    with open(path, "r") as f:
        content = f.read()

    devices = content.split("\n\n")
    for dev in devices:
        if device_name in dev:
            match = re.search(r"Handlers=.*(event\d+)", dev)
            if match:
                return f"/dev/input/{match.group(1)}"
    return None

def main():
    print(f"[*] Searching for input device: '{TARGET_DEVICE_NAME}'...")
    event_path = get_event_path(TARGET_DEVICE_NAME)

    if not event_path:
        print(f"[!] Could not find device '{TARGET_DEVICE_NAME}'")
        print("    Run 'cat /proc/bus/input/devices' to check the exact name.")
        sys.exit(1)

    print(f"[*] Found Power Button at: {event_path}")
    print(f"[*] Listening for Trigger Code {TRIGGER_CODE}...")

    try:
        f = open(event_path, "rb")
    except PermissionError:
        print("Error: Permission denied. Run with sudo!")
        sys.exit(1)

    while True:
        # Read standard Linux input event (24 bytes)
        data = f.read(24)

        if data and len(data) == 24:
            # Unpack: time(8), time(8), type(2), code(2), value(4)
            (tv_sec, tv_usec, type, code, value) = struct.unpack('llHHi', data)

            # Type 1 is EV_KEY
            if type == 1:
                # Debug: Uncomment this to see ANY key press code
                # print(f"Detected Key: {code} Value: {value}")

                if code == TRIGGER_CODE and value == 1:
                    print(f"\n[!] POWER BUTTON PRESSED! Launching Attack...")

                    # Run the attack
                    os.system(f"python3 {ATTACK_SCRIPT}")

                    # Wait 2 seconds so we don't trigger twice
                    time.sleep(2)

if __name__ == "__main__":
    main()