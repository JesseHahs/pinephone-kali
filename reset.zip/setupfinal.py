#!/usr/bin/env python3
import os
import sys
import time

print("--- PinePhone USB Keyboard Setup ---")

# 1. Automatic Initialization (Mount + Modprobe)
print("[+] Initializing Kernel...")
# Try to mount configfs. We send errors to /dev/null in case it's already mounted.
os.system("mount -t configfs none /sys/kernel/config 2>/dev/null")
# Load the required kernel module
os.system("modprobe libcomposite")

# 2. Configuration Variables
GADGET_DIR = "/sys/kernel/config/usb_gadget/my_keyboard"
FUNCTIONS_DIR = os.path.join(GADGET_DIR, "functions/hid.g1")
CONFIGS_DIR = os.path.join(GADGET_DIR, "configs/c.1")

def write_file(path, content):
    with open(path, "w") as f:
        f.write(content)

def write_bytes(path, content):
    with open(path, "wb") as f:
        f.write(content)

# 3. Cleanup (Remove old gadget if it exists)
if os.path.exists(GADGET_DIR):
    print("  ! Gadget exists. Cleaning up old configuration...")
    # Disable gadget first
    os.system(f"echo '' > {GADGET_DIR}/UDC 2>/dev/null")
    # Give kernel a moment to release lock
    time.sleep(0.2)
    # Remove links and directories
    os.system(f"rm {CONFIGS_DIR}/hid.g1 2>/dev/null")
    os.system(f"rmdir {CONFIGS_DIR}/strings/0x409 2>/dev/null")
    os.system(f"rmdir {CONFIGS_DIR} 2>/dev/null")
    os.system(f"rmdir {FUNCTIONS_DIR} 2>/dev/null")
    os.system(f"rmdir {GADGET_DIR}/strings/0x409 2>/dev/null")
    os.system(f"rmdir {GADGET_DIR} 2>/dev/null")

# 4. Create Directory Structure
print("[+] Creating Gadget Directories...")
os.makedirs(os.path.join(GADGET_DIR, "strings/0x409"), exist_ok=True)
os.makedirs(os.path.join(CONFIGS_DIR, "strings/0x409"), exist_ok=True)
os.makedirs(FUNCTIONS_DIR, exist_ok=True)

# 5. Write ID and Strings
print("[+] Setting IDs...")
write_file(os.path.join(GADGET_DIR, "idVendor"), "0x1d6b")
write_file(os.path.join(GADGET_DIR, "idProduct"), "0x0104")
write_file(os.path.join(GADGET_DIR, "bcdDevice"), "0x0100")
write_file(os.path.join(GADGET_DIR, "bcdUSB"), "0x0200")

write_file(os.path.join(GADGET_DIR, "strings/0x409/serialnumber"), "fedcba9876543210")
write_file(os.path.join(GADGET_DIR, "strings/0x409/manufacturer"), "Kali Linux")
write_file(os.path.join(GADGET_DIR, "strings/0x409/product"), "Generic HID Keyboard")

write_file(os.path.join(CONFIGS_DIR, "strings/0x409/configuration"), "Config 1")
write_file(os.path.join(CONFIGS_DIR, "MaxPower"), "250")

# 6. HID Parameters
print("[+] Configuring HID Function...")
write_file(os.path.join(FUNCTIONS_DIR, "protocol"), "1")
write_file(os.path.join(FUNCTIONS_DIR, "subclass"), "1")
write_file(os.path.join(FUNCTIONS_DIR, "report_length"), "8")

# 7. Write Binary Report Descriptor
# This is the corrected 63-byte descriptor that fixes Code 10
REPORT_DESC = bytes([
    0x05, 0x01, 0x09, 0x06, 0xa1, 0x01, 0x05, 0x07, 0x19, 0xe0, 0x29, 0xe7, 0x15, 0x00, 0x25, 0x01,
    0x75, 0x01, 0x95, 0x08, 0x81, 0x02, 0x95, 0x01, 0x75, 0x08, 0x81, 0x03, 0x95, 0x05, 0x75, 0x01,
    0x05, 0x08, 0x19, 0x01, 0x29, 0x05, 0x91, 0x02, 0x95, 0x01, 0x75, 0x03, 0x91, 0x03, 0x95, 0x06,
    0x75, 0x08, 0x15, 0x00, 0x25, 0x65, 0x05, 0x07, 0x19, 0x00, 0x29, 0x65, 0x81, 0x00, 0xc0
])
write_bytes(os.path.join(FUNCTIONS_DIR, "report_desc"), REPORT_DESC)

# 8. Link Function
try:
    os.symlink(FUNCTIONS_DIR, os.path.join(CONFIGS_DIR, "hid.g1"))
except FileExistsError:
    pass

# 9. Enable Gadget (Bind to UDC)
print("[+] Enabling Gadget...")
# Find UDC
try:
    udc_name = os.listdir("/sys/class/udc")[0]
    write_file(os.path.join(GADGET_DIR, "UDC"), udc_name)
    print(f"SUCCESS! Gadget active on controller: {udc_name}")
except IndexError:
    print("ERROR: No USB Controller found in /sys/class/udc")
    print("Make sure your USB cable is plugged in!")